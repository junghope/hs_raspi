import RPi.GPIO as GPIO
import time
import requests
import json

# 핀 설정
TRIG = 18
ECHO = 24

# 카카오톡 설정
url = "https://kapi.kakao.com/v2/api/talk/memo/default/send"
headers = {
    "Content-Type": "application/x-www-form-urlencoded",
    "Authorization": "Bearer " + "7X"
}

data = {
    "template_object": json.dumps({
        "object_type": "text",
        "text": "물건이 도난되었습니다!",
        "link": {
            "web_url": "https://developers.kakao.com"
        }
    })
}
def setup():
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(TRIG, GPIO.OUT)
    GPIO.setup(ECHO, GPIO.IN)

def get_distance():
    GPIO.output(TRIG, True)
    time.sleep(0.00001)
    GPIO.output(TRIG, False)
    
    while GPIO.input(ECHO) == 0:
        start = time.time()
    while GPIO.input(ECHO) == 1:
        end = time.time()
    
    distance = (end - start) * 17150
    return round(distance, 1)

def send_kakao():
    try:
        response = requests.post(url, headers=headers, data=data)
        print("카카오톡 전송:", response.status_code)
    except:
        print("카카오톡 전송 실패")

def main():
    setup()
    print("도난 감지 시스템 시작")
    print("기준: 3초 동안 20cm 이상")
    
    start_time = None
    
    try:
        while True:
            distance = get_distance()
            print(f"거리: {distance}cm")
            
            if distance >= 20:
                if start_time is None:
                    start_time = time.time()
                    print("거리 감지 시작...")
                elif time.time() - start_time >= 3:
                    print("도난 감지! 카카오톡 전송")
                    send_kakao()
                    break
            else:
                start_time = None
                print("정상")
            
            time.sleep(0.5)
            
    except KeyboardInterrupt:
        print("프로그램 종료")
    finally:
        GPIO.cleanup()

if __name__ == "__main__":
    main()
