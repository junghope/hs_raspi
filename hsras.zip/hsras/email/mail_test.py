import smtplib
from email.mime.text import MIMEText

# 설정값 입력
GMAIL_USER = "@gmail.com"
GMAIL_PASSWORD = ""
TO_EMAIL = "@gmail.com"

try:
    msg = MIMEText("테스트 메시지입니다")
    msg['Subject'] = "Gmail 연결 테스트"
    msg['From'] = GMAIL_USER
    msg['To'] = TO_EMAIL
    
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login(GMAIL_USER, GMAIL_PASSWORD)
    server.sendmail(GMAIL_USER, TO_EMAIL, msg.as_string())
    server.quit()
    
    print("✅ Gmail 테스트 성공!")
except Exception as e:
    print(f"❌ Gmail 테스트 실패: {e}")
