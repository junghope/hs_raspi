import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)# BCM GPIO 사용으로 설정

sensor = 18# 수위센서 핀 설정
led1 = 23  # LED1 핀 설정 (낮은 수위)
led2 = 24  # LED2 핀 설정 (높은 수위)

GPIO.setup(sensor, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)  # 센서 핀을 입력으로 설정
GPIO.setup(led1, GPIO.OUT)   # LED1 핀을 출력으로 설정
GPIO.setup(led2, GPIO.OUT)   # LED2 핀을 출력으로 설정

try :
    while True :
        water_detected = GPIO.input(sensor)    # 센서 상태 읽기
        time.sleep(0.5) # 0.5초 지연

        if water_detected == 1 :# 물이 감지된 경우
            GPIO.output(led1, True)  # LED1 켜기
            GPIO.output(led2, True)  # LED2 켜기
            print("Water Level : HIGH (물 많음)")
        else :# 물이 감지되지 않은 경우  
            GPIO.output(led1, True)  # LED1 켜기
            GPIO.output(led2, False) # LED2 끄기
            print("Water Level : LOW (물 부족)")

except KeyboardInterrupt:
      pass
finally:
      GPIO.output(led1, False)  # LED1 끄기
      GPIO.output(led2, False)  # LED2 끄기
      GPIO.cleanup()

'''
<연결 방법>
수위센서 (T1529P 또는 디지털 수위센서):
- VCC → 3.3V
- GND → GND  
- Signal → GPIO 18

LED 연결:
- LED1: GPIO 23 → 220Ω 저항 → 초록LED → GND
- LED2: GPIO 24 → 220Ω 저항 → 빨강LED → GND

<동작 원리>
- 물이 적을 때: LED1만 켜짐 (초록불)
- 물이 많을 때: LED1, LED2 모두 켜짐 (초록불+빨강불)

<실행 결과>
Water Level : LOW (물 부족)
Water Level : LOW (물 부족)
Water Level : HIGH (물 많음)
Water Level : HIGH (물 많음)
Water Level : LOW (물 부족)
'''