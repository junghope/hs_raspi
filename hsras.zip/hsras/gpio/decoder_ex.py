import RPi.GPIO as GPIO
import time

LED = 22
BUTTON = 27

GPIO.cleanup()
GPIO.setmode(GPIO.BCM)
GPIO.setup(LED, GPIO.OUT)
GPIO.setup(BUTTON, GPIO.IN, pull_up_down=GPIO.PUD_UP)

print("1비트 디코더")
print("버튼 안누름(0): PWM 모드")
print("버튼 누름(1): 깜빡임 모드")

try:
    pwm = GPIO.PWM(LED, 100)
    pwm.start(0)
    brightness = 0
    
    while True:
        button = GPIO.input(BUTTON)
        
        if button == GPIO.HIGH:  # 0 입력 - PWM 모드
            print(f"입력: 0, 밝기: {brightness}%")
            pwm.ChangeDutyCycle(brightness)
            brightness += 20
            if brightness > 100:
                brightness = 0
            time.sleep(0.5)
            
        else:  # 1 입력 - 깜빡임 모드
            print("입력: 1, 깜빡임")
            pwm.ChangeDutyCycle(0)
            GPIO.output(LED, GPIO.HIGH)
            time.sleep(0.5)
            GPIO.output(LED, GPIO.LOW)
            time.sleep(0.5)

except:
    print("오류 발생")
    
finally:
    pwm.stop()
    GPIO.cleanup()
    print("종료")

