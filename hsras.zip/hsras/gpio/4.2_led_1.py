import RPi.GPIO as GPIO	# RPi.GPIO 패키지 사용
import time # 1초 지연을 위해서 time 사용

LED=4   # LED포트를 4로 설정(pin no.7)

GPIO.setmode(GPIO.BCM)# BCM GPIO 사용으로 설정
GPIO.setup(LED, GPIO.OUT, initial=GPIO.LOW)# BCM4 핀을 출력으로 설정하고 초기값을 LOW로 설정

for i in range(1, 6):# 5회 반복

   GPIO.output(LED, True)# LED 켜기
   time.sleep(1)# 1초 지연
   GPIO.output(LED, False)# LED 끄기
   time.sleep(1)# 1초 지연

