import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)# BCM GPIO 사용으로 설정

light_sensor = 18# 조도센서 핀 설정
led1 = 23  # LED1 핀 설정 (밝음 표시)
led2 = 24  # LED2 핀 설정 (어두움 표시)

GPIO.setup(light_sensor, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)  # 센서 핀을 입력으로 설정
GPIO.setup(led1, GPIO.OUT)   # LED1 핀을 출력으로 설정
GPIO.setup(led2, GPIO.OUT)   # LED2 핀을 출력으로 설정

try :
    while True :
        light_detected = GPIO.input(light_sensor)    # 조도센서 상태 읽기
        time.sleep(0.5) # 0.5초 지연

        if light_detected == 1 :# 밝은 빛이 감지된 경우
            GPIO.output(led1, True)  # LED1 켜기 (밝음)
            GPIO.output(led2, False) # LED2 끄기
            print("Light Level : BRIGHT (밝음)")
        else :# 어두운 경우  
            GPIO.output(led1, False) # LED1 끄기
            GPIO.output(led2, True)  # LED2 켜기 (어두움)
            print("Light Level : DARK (어두움)")

except KeyboardInterrupt:
      pass
finally:
      GPIO.output(led1, False)  # LED1 끄기
      GPIO.output(led2, False)  # LED2 끄기
      GPIO.cleanup()

'''
<연결 방법>
디지털 조도센서 모듈 (포토다이오드 + 비교기):
- VCC → 3.3V
- GND → GND  
- DO (Digital Output) → GPIO 18

LED 연결:
- LED1: GPIO 23 → 220Ω 저항 → 노랑LED → GND (밝음 표시)
- LED2: GPIO 24 → 220Ω 저항 → 파랑LED → GND (어두움 표시)

<동작 원리>
- 밝을 때: LED1만 켜짐 (노랑불) - "낮"
- 어두울 때: LED2만 켜짐 (파랑불) - "밤"

<센서 종류>
1. 디지털 조도센서 모듈 (추천): LM393 + 포토다이오드
   - 임계값 조절 가능 (가변저항)
   - 디지털 출력 (HIGH/LOW)
   
2. CDS 포토셀 + 비교기
   - 간단한 회로
   - 임계값 고정

<실행 결과>
Light Level : BRIGHT (밝음)
Light Level : BRIGHT (밝음)  
Light Level : DARK (어두움)
Light Level : DARK (어두움)
Light Level : BRIGHT (밝음)

<응용 아이디어>
- 자동 조명 제어
- 낮/밤 구분
- 창문 커튼 자동 제어
- 보안등 자동 켜기
'''