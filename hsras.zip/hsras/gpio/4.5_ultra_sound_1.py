import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)# BCM GPIO 사용으로 설정

trig = 3# Trig핀 설정
echo = 2# Echo핀 설정

GPIO.setup(trig, GPIO.OUT)  # Trig 핀을 출력으로 설정
GPIO.setup(echo, GPIO.IN)   # Echo 핀을 입력으로

try :
    while True :
        GPIO.output(trig, False)    # Trig핀 초기 설정
        time.sleep(0.5) # 0.5초 지연

        GPIO.output(trig, True) # Trig핀으로 펄스 출력
        time.sleep(0.00001) #시간지연
        GPIO.output(trig, False)

        while GPIO.input(echo) == 0 :# Echo핀 입력 없을 경우
            pulse_start = time.time()# 시간 저장

        while GPIO.input(echo) == 1 :# Echo핀 입력 있을 경우
            pulse_end = time.time() # 시간 저장

        pulse_duration = pulse_end - pulse_start    # 시간 간격 저장
        distance = pulse_duration * (340*100) / 2   # 거리 계산
        distance = round(distance, 2)   #반사되어 돌아오는 시간으로 거리를 계산,이동거리 2배 -> 2로 나누기


        print("Distance : ", distance, "cm")
except KeyboardInterrupt:
      pass
finally:
      GPIO.cleanup()

'''
<실행 결과>
Distance : 4.66 cm
Distance : 4.58 cm
Distance : 4.59 cm
Distance : 4.3 cm
Distance : 5.68 cm
'''
