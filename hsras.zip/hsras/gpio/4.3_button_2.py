import RPi.GPIO as GPIO
import time

LED = 4
KEY = 5

GPIO.setmode(GPIO.BCM)
GPIO.setup(LED, GPIO.OUT)
GPIO.setup(KEY, GPIO.IN, pull_up_down=GPIO.PUD_UP)

try:
	while True:
		if GPIO.input(KEY)==False:
			GPIO.output(LED, True)
		else:
			GPIO.output(LED, False)
		time.sleep(0.1)
except KeyboardInterrupt:
	pass
finally:
	GPIO.cleanup()
