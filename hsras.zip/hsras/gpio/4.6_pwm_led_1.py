import RPi.GPIO as GPIO
import time

LED=4

GPIO.setmode(GPIO.BCM)  # BCM 모드로 설정
GPIO.setup(LED, GPIO.OUT)   # BCM4 핀을 출력으로 설정

try:
    pwm = GPIO.PWM(LED, 100)    # LED핀으로 100Hz 출력
    pwm.start(0)    # Duty비 0으로 설정 : LED OFF
    while True:
        for i in range(10):
             pwm.ChangeDutyCycle(i*10)  # 0~100％ 듀티비로 출력
             time.sleep(1)             
except KeyboardInterrupt:
    pass
finally:
    pwm.stop()  #PWM출력을 종료
    GPIO.cleanup()

'''
<실행 결과>
LED가 10단계로 점점 밝아졌다가 꺼지기를 반복 
'''