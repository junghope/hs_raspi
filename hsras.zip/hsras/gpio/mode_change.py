import RPi.GPIO as GPIO
import time

LED = 4
BUTTON = 18

GPIO.cleanup()
GPIO.setmode(GPIO.BCM)
GPIO.setup(LED, GPIO.OUT)
GPIO.setup(BUTTON, GPIO.IN, pull_up_down=GPIO.PUD_UP)

mode = 0  # 0:켜짐, 1:1초깜빡임, 2:0.5초깜빡임, 3:꺼짐
mode_names = ["켜짐", "1초깜빡임", "0.5초깜빡임", "꺼짐"]

print("LED 모드 변경")
print("버튼을 누르면 모드 변경")
print("Ctrl+C로 종료")

try:
    while True:
        # 버튼이 눌렸으면 모드 변경
        if GPIO.input(BUTTON) == GPIO.LOW:
            mode = (mode + 1) % 4
            print(f"모드: {mode_names[mode]}")
            time.sleep(0.3)  # 디바운싱
            while GPIO.input(BUTTON) == GPIO.LOW:  # 버튼 떼어질 때까지 대기
                time.sleep(0.1)
        
        # 각 모드별 LED 동작
        if mode == 0:    # 켜짐
            GPIO.output(LED, GPIO.HIGH)
            time.sleep(0.1)
        elif mode == 1:  # 1초 깜빡임
            GPIO.output(LED, GPIO.HIGH)
            time.sleep(1)
            GPIO.output(LED, GPIO.LOW)
            time.sleep(1)
        elif mode == 2:  # 0.5초 깜빡임
            GPIO.output(LED, GPIO.HIGH)
            time.sleep(0.5)
            GPIO.output(LED, GPIO.LOW)
            time.sleep(0.5)
        else:            # 꺼짐
            GPIO.output(LED, GPIO.LOW)
            time.sleep(0.1)

except KeyboardInterrupt:
    print("\n종료")
    
finally:
    GPIO.cleanup()
