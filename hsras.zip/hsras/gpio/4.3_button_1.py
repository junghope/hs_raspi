import RPi.GPIO as GPIO
import time
LED = 4
KEY = 5# 버튼포트를 5로 설정

GPIO.setmode(GPIO.BCM)# BCM GPIO 사용으로 설정
GPIO.setup(LED, GPIO.OUT)# BCM.4 핀을 출력으로 설정
GPIO.setup(KEY, GPIO.IN)# BCM.5 핀을 입력으로 설정
   
try:
    while True:# 무한 반복
        if GPIO.input(KEY)==True:# 5번핀 입력이 HIGH(버튼 눌림)
            GPIO.output(LED, True)# LED 켜기
        elif GPIO.input(KEY)==False:# 5번핀 입력이 HIGH(버튼 눌리지 않음) 
            GPIO.output(LED, False)# LED 끄기
except KeyboardInterrupt:
      pass
finally:
      GPIO.cleanup()# 강제로 프로그램이 종료되는 경우, GPIO 자원을 해제하기 위해 사용

