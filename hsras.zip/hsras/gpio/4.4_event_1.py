import RPi.GPIO as GPIO
import time
LED = 4
KEY = 5

GPIO.setmode(GPIO.BCM)
GPIO.setup(LED, GPIO.OUT)   # BCM.4 핀을 출력으로 설정
GPIO.setup(KEY, GPIO.IN)    # BCM.5 핀을 입력으로 설정

def isr_key_event(pin): # 인터럽트 서비스 루틴 pin : BCM 핀 번호
    print("Key is pressed [%d]" %pin)
    if GPIO.input(LED)==True:   # LED가 켜져 있으면
        GPIO.output(LED, False) # LED 끄기
    elif GPIO.input(LED)==False:# LED가 꺼져 있으면
        GPIO.output(LED, True)  # LED 켜기


# 인터럽트 서비스 루틴 추가
GPIO.add_event_detect(KEY,GPIO.FALLING, callback=isr_key_event,  bouncetime=300)

sec = 0
try:    
    while True:
        print("sec = %d" %sec)  # 1초단위 출력
        sec = sec + 1
        time.sleep(1)   # 1초 지연
except KeyboardInterrupt:
      pass
finally:
      GPIO.cleanup()

'''
<실행 결과>
sec = 3
sec = 4
sec = 5
Key is pressed [5]
sec = 6
sec = 7
Key is pressed [5]
sec = 8
'''