from flask import Flask

app = Flask(__name__)       # 인스턴스(객체) 생성

@app.route('/')             # URL “/” 루트로 요청이 오면   
def hello():# hello() 함수 실행
    return 'Hello Flask'

@app.route('/sub1')                # “/sub1” 으로 요청이 오면  
def sub1():# sub1() 함수 실행
    return 'SUB1 Page'

@app.route('/sub2')                # “/sub2” 으로 요청이 오면  
def sub2():# sub2() 함수 실행
    return 'SUB2 Page'

if __name__ == '__main__':
    app.run(debug=True, port=80, 
                       host='0.0.0.0') 
