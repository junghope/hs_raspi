from flask import Flask, render_template    # Flask, Render 패키지 사용

app = Flask(__name__) # 인스턴스(객체) 생성

@app.route('/')     # URL “/” 루트로 요청이 오면        
def index():        # index() 함수 실행
    return render_template('html_test.html')# webapp/templates/html_test.html 피일 랜더링

if __name__ == '__main__':
    app.run(debug=True, port=80, host='0.0.0.0') 
