from flask import Flask # Flask 패키지 사용

app = Flask(__name__)   # 인스턴스(객체) 생성

@app.route('/')  # URL “/” 루트로 요청이 오면
                 
def hello():     # hello 함수 실행
    return 'Hello Flask'

if __name__ == '__main__':
    app.run(debug=True, port=80, host='0.0.0.0') # 80포트로 서비스

