from flask import Flask, render_template, jsonify
import RPi.GPIO as GPIO
import time
import requests
import json
import threading

app = Flask(__name__)

# 핀 설정
TRIG = 18
ECHO = 24
LED = 4

# 카카오톡 설정
url = "https://kapi.kakao.com/v2/api/talk/memo/default/send"
headers = {
    "Content-Type": "application/x-www-form-urlencoded",
    "Authorization": "Bearer " + "7sa_Kllw0xcptw6neMo_Ea4YK6UmKqEZAAAAAQoXIiAAAAGX23lziVXuKbObXTiX"
}
data = {
    "template_object": json.dumps({
        "object_type": "text",
        "text": "물건이 도난되었습니다!",
        "link": {
            "web_url": "https://developers.kakao.com"
        }
    })
}

# 전역 변수
current_distance = 0
is_monitoring = False
theft_detected = False
detection_start_time = None
detection_distance = 20

def init_gpio():
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(TRIG, GPIO.OUT)
    GPIO.setup(ECHO, GPIO.IN)
    GPIO.setup(LED, GPIO.OUT)     
    GPIO.output(LED, False)

def get_distance():
    GPIO.output(TRIG, True)
    time.sleep(0.00001)
    GPIO.output(TRIG, False)
    
    while GPIO.input(ECHO) == 0:
        start = time.time()
    while GPIO.input(ECHO) == 1:
        end = time.time()
    
    distance = (end - start) * 17000
    return round(distance, 1)

def send_kakao():
    try:
        response = requests.post(url, headers=headers, data=data)
        print("카카오톡 전송:", response.status_code)
    except:
        print("카카오톡 전송 실패")

def monitor_loop():
    global current_distance, theft_detected, detection_start_time, is_monitoring
    
    while is_monitoring:
        current_distance = get_distance()
        print(f"거리: {current_distance}cm")
        
        if current_distance >= detection_distance:
            GPIO.output(LED, True)        # ← 이 줄 추가 (LED 켜기)
            if detection_start_time is None:
                detection_start_time = time.time()
                print("거리 감지 시작...")
            elif time.time() - detection_start_time >= 3:
                if not theft_detected:
                    theft_detected = True
                    print("도난 감지! 카카오톡 전송")
                    send_kakao()
        else:
            GPIO.output(LED, False)       # ← 이 줄 추가 (LED 끄기)
            detection_start_time = None
            theft_detected = False
            print("정상")
        
        time.sleep(1)

@app.route('/')
def index():
    return render_template('theft_detect.html')

@app.route('/start_monitoring')
def start_monitoring():
    global is_monitoring
    is_monitoring = True
    thread = threading.Thread(target=monitor_loop)
    thread.daemon = True
    thread.start()
    return jsonify({"status": "success", "message": "모니터링 시작"})

@app.route('/stop_monitoring')
def stop_monitoring():
    global is_monitoring
    is_monitoring = False
    return jsonify({"status": "success", "message": "모니터링 중지"})

@app.route('/reset_theft')
def reset_theft():
    global theft_detected, detection_start_time
    theft_detected = False
    detection_start_time = None
    return jsonify({"status": "success", "message": "리셋 완료"})

@app.route('/get_status')
def get_status():
    remaining_time = 0
    if detection_start_time and not theft_detected:
        remaining_time = max(0, 3 - (time.time() - detection_start_time))
    
    return jsonify({
        "is_monitoring": is_monitoring,
        "current_distance": current_distance,
        "detection_distance": detection_distance,
        "theft_detected": theft_detected,
        "detection_time_remaining": remaining_time
    })

@app.route('/set_distance/<int:distance>')
def set_distance(distance):
    global detection_distance
    detection_distance = distance
    return jsonify({"status": "success", "message": f"기준 거리: {distance}cm"})

@app.route('/test_kakao')
def test_kakao():
    send_kakao()
    return jsonify({"status": "success", "message": "카카오톡 테스트 전송"})

if __name__ == '__main__':
    # GPIO 초기화
    init_gpio()
    # debug=False로 설정하거나 use_reloader=False 옵션 사용
    # 방법 1: debug=False
    app.run(debug=False, port=80, host='0.0.0.0')
    # 방법 2: debug=True이지만 reloader 비활성화 (아래 주석 해제하고 위 줄 주석 처리)
    # app.run(debug=True, port=80, host='0.0.0.0', use_reloader=False)
