from flask import Flask, request, render_template
import RPi.GPIO as GPIO
import atexit

LED = 4
app = Flask(__name__)

# GPIO 초기화 함수
def init_gpio():
    try:
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(LED, GPIO.OUT, initial=GPIO.LOW)
        print("GPIO 초기화 완료")
    except Exception as e:
        print(f"GPIO 초기화 오류: {e}")
        # 이미 초기화된 경우 cleanup 후 재시도
        GPIO.cleanup()
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(LED, GPIO.OUT, initial=GPIO.LOW)
        print("GPIO 재초기화 완료")

# 애플리케이션 종료 시 GPIO cleanup
def cleanup_gpio():
    GPIO.cleanup()
    print("GPIO cleanup 완료")

# cleanup 함수를 종료 시 자동 실행되도록 등록
atexit.register(cleanup_gpio)

@app.route('/led_control')
def led_control():
    return render_template('led_control.html')

@app.route('/led_control_act', methods=['GET'])
def led_control_act(): 
    if request.method == 'GET': 
        status = ''
        led = request.args["led"]
        try:
            if led == '1':
                GPIO.output(LED, True)
                status = 'ON'
            else: 
                GPIO.output(LED, False)
                status = 'OFF'
        except Exception as e:
            print(f"GPIO 출력 오류: {e}")
            status = 'ERROR'
        
        # 웹브라우저로 LED버튼의 상태를 전달
        return render_template('led_control.html', ret=status)

if __name__ == '__main__':
    # GPIO 초기화
    init_gpio()
    
    # debug=False로 설정하거나 use_reloader=False 옵션 사용
    # 방법 1: debug=False
    app.run(debug=False, port=80, host='0.0.0.0')
    
    # 방법 2: debug=True이지만 reloader 비활성화 (아래 주석 해제하고 위 줄 주석 처리)
    # app.run(debug=True, port=80, host='0.0.0.0', use_reloader=False)
